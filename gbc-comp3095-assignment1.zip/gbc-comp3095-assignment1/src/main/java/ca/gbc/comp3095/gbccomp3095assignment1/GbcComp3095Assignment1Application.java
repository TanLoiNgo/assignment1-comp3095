package ca.gbc.comp3095.gbccomp3095assignment1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GbcComp3095Assignment1Application {

    public static void main(String[] args) {
        SpringApplication.run(GbcComp3095Assignment1Application.class, args);
    }

}
